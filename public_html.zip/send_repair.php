<?php

// $returnData = array();
// $phone = trim(htmlspecialchars($_POST['phone']));
// $date = trim(htmlspecialchars($_POST['date']));
// $carModel = trim(htmlspecialchars($_POST['carModel']));
// $service = trim(htmlspecialchars($_POST['service']));
// $repairType = trim(htmlspecialchars($_POST['repairType']));
// $faster = trim(htmlspecialchars($_POST['faster']));




// $to  = "<mail@trustcar.ru>" ; 


// $subject = "Запись на ремонт"; 

// $message = ' <p>Содержание заявки</p> <br> <b>Телефон:</b>'.$phone.' <br> <br/> <br> <b>Марка автомобиля: </b>'.$carModel.'<br> <b>Услуга: </b>'.$service.'<br> <b>Вид ремонта: </b>'.$repairType.' <br> <b>Дата: </b>'.$date. '<br> <b>Срочно: </b>'.$faster. ' ';

// $headers  = "Content-type: text/html; charset=utf-8 \r\n"; 
// $headers .= "From: Запись на ремонт <admin@kat23krd.ru>\r\n"; 
// $headers .= "Reply-To: admin@kat23krd.ru\r\n"; 

// mail($to, $subject, $message, $headers); 

// echo json_encode($returnData['success'] = true);
?>